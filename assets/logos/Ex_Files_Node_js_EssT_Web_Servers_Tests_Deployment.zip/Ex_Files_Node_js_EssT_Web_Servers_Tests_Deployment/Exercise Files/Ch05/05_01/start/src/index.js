import app from "./app.js";

app.listen(3000, () =>
  console.log("ski dictionary running at 3000")
);
