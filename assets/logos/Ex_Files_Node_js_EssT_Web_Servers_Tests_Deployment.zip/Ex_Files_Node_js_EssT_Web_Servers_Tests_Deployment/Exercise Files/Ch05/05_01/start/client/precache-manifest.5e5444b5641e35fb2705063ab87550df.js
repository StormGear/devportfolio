self.__precacheManifest = [
  {
    "revision": "23b3782bdaf5f60bc0fd560196669dfe",
    "url": "./static/media/ski.23b3782b.jpg"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "1b7d18ba06ac8f214652",
    "url": "./static/js/main.828aa341.chunk.js"
  },
  {
    "revision": "fa315494e00edaef2d70",
    "url": "./static/js/2.811d0a14.chunk.js"
  },
  {
    "revision": "4987068c279821d2da97f247017f1e1a",
    "url": "./index.html"
  }
];