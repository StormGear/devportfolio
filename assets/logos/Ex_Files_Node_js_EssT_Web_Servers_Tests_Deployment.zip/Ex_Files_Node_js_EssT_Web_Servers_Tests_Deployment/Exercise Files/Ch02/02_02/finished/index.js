import fs from "fs";

console.log(fs);
